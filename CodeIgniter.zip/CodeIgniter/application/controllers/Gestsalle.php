<?php
class Gestsalle extends CI_Controller{


  public function __construct()
      {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Db_model');
      }

  public function afficher()

        {
          $datas['sallesPoly'] = $this->Db_model->get_all_salles_pol();
          //$datas['equipements'] = $this->Db_model->get_all_equipements();

        	$this->load->view('gestsalle',$datas);



        }


}
