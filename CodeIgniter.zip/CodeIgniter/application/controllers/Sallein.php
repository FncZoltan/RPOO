<?php
class Sallein extends CI_Controller{


  public function __construct()
      {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Db_model');
      }

  public function afficher($id)

        {
          $id = (int) $id;

          $datas['salles'] = $this->Db_model->get_salle($id);

        	$this->load->view('sallein',$datas);


        }


      }
?>
