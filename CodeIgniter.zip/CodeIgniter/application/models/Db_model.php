<?php
class Db_model extends CI_Model
{
      public function __construct()
      {
                $this->load->database();
      }


      //Lister tout les salles
      public function get_all_salles()
	{
				$query = $this->db->query("SELECT * FROM t_salle_sal");
				return $query->result_array();
	}
      public function get_all_salles_pol()
      {
        $query = $this->db->query("SELECT * FROM t_salle_polyvalente_spl");
        return $query->result_array();
      }

      public function get_salle($id){
        $query = $this->db->query("SELECT * FROM t_salle_sal where sal_spl_id=$id");
        return $query->result_array();
      }

	public function get_all_equipements()
  {
    $query = $this->db->query("SELECT eqs_id, eqs_type, eqs_description, eqs_disponibilite FROM t_equipement_statique_eqs WHERE eqs_sal_id = 1");
    return $query->result_array();
  }




}
